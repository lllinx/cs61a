.read data.sql

-- Q1
create table flight_costs as
  select "REPLACE THIS LINE WITH YOUR SOLUTION";

-- Q2
create table schedule as
  select "REPLACE THIS LINE WITH YOUR SOLUTION";

-- Q3
create table shopping_cart as
  select "REPLACE THIS LINE WITH YOUR SOLUTION";

-- Q4
create table number_of_options as
  select "REPLACE THIS LINE WITH YOUR SOLUTION";

-- Q5
create table calories as
  select "REPLACE THIS LINE WITH YOUR SOLUTION";

-- Q6
create table healthiest_meats as
  select "REPLACE THIS LINE WITH YOUR SOLUTION";

-- Q7
create table average_prices as
  select "REPLACE THIS LINE WITH YOUR SOLUTION";

-- Q8
create table lowest_prices as
  select "REPLACE THIS LINE WITH YOUR SOLUTION";

-- Q9
create table shopping_list as
  select "REPLACE THIS LINE WITH YOUR SOLUTION";

-- Q10
create table total_bandwidth as
  select "REPLACE THIS LINE WITH YOUR SOLUTION";
